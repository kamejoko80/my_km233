#-------------------------------------------------------
#                LINUX IMAGE LOCATION
#-------------------------------------------------------
export DFT_IMAGE=/root/kernel/linux-2.6.35.3-dev/arch/arm/boot/zImage

#-------------------------------------------------------
#                U-BOOT IMAGE LOCATION
#-------------------------------------------------------
#export DFT_UBOOT=/root/ltib/rootfs/boot/u-boot
#export DFT_UBOOT=/root/ltib/rpm/BUILD/u-boot-2009.08-km233-22022011/u-boot
export DFT_UBOOT=./u-boot

#-------------------------------------------------------
#                BUILD ENVIRONMENT PARAMETERS
#-------------------------------------------------------

#export MACH_TYPE=MACH_STMP378X
export MACH_TYPE=MACH_MX23
export CROSS_COMPILE=arm-none-linux-gnueabi-
export BOARD=stmp378x_dev
export DDR_SPEED=DDR_133M
#export DDR_SPEED=DDR_96M
export CMDLINE1="console=ttyAM0,115200 ssp1=spi1 ssp2=mmc root=/dev/mmcblk0p2 rw rootwait lcd_panel=tvenc_ntsc no_console_suspend"

make CROSS_COMPILE=$CROSS_COMPILE BOARD=$BOARD DDR_SPEED=$DDR_SPEED CMDLINE1="$CMDLINE1" clean all

