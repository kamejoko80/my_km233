ls /dev/ | grep sdb
