
echo copying boot image, please wait for a while...

dd if=/dev/zero of=mmc_boot_partition.raw bs=512 count=4

# Boot Linux directly
dd if=imx23_linux.sb of=mmc_boot_partition.raw ibs=512 seek=4 conv=sync,notrunc

# Use u-boot
#dd if=imx23_uboot.sb of=mmc_boot_partition.raw ibs=512 seek=4 conv=sync,notrunc

dd if=mmc_boot_partition.raw of=/dev/sdb1
echo done!
