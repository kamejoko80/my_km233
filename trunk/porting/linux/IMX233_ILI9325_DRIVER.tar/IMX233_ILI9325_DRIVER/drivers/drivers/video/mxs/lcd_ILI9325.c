/*
 * Author: Alexander Kudjashev <Kudjashev@gmail.com>
 * 30/07/2012: Dang Minh Phuong <phuongminh.dang@gmai.com> Add support ILI9325 TFT LCD
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 */

#include <linux/init.h>
#include <linux/delay.h>
#include <linux/clk.h>
#include <linux/notifier.h>
#include <linux/regulator/consumer.h>
#include <linux/platform_device.h>

#include <mach/device.h>
#include <mach/lcdif.h>
#include <mach/regs-pwm.h>
#include <mach/system.h>

#define CMD  0
#define DATA 1

#define lcdif_read(reg) __raw_readl(REGS_LCDIF_BASE + reg)
#define lcdif_write(reg,val) __raw_writel(val, REGS_LCDIF_BASE + reg)

static dma_addr_t inb_phys;
static struct clk *lcd_clk;
static struct tasklet_struct mpulcd_tasklet;
static spinlock_t mpulcd_lock;

static void mpulcd_setup_panel_register(char data, char val)
{

	lcdif_write(HW_LCDIF_CTRL_CLR,
		BM_LCDIF_CTRL_LCDIF_MASTER |
		BM_LCDIF_CTRL_RUN);

	lcdif_write(HW_LCDIF_CTRL1_CLR,
		BM_LCDIF_CTRL1_CUR_FRAME_DONE_IRQ_EN);

	/* Change to single byte to send the LCD cmd */
	lcdif_write(HW_LCDIF_TRANSFER_COUNT,
		BF_LCDIF_TRANSFER_COUNT_V_COUNT(1) |
		BF_LCDIF_TRANSFER_COUNT_H_COUNT(1));

	/* No swizzle (little-endian) */
	lcdif_write(HW_LCDIF_CTRL_CLR,
		BM_LCDIF_CTRL_INPUT_DATA_SWIZZLE);

	if (data)
		lcdif_write(HW_LCDIF_CTRL_SET, BM_LCDIF_CTRL_DATA_SELECT);
	else
		lcdif_write(HW_LCDIF_CTRL_CLR, BM_LCDIF_CTRL_DATA_SELECT);

	lcdif_write(HW_LCDIF_CTRL_SET, BM_LCDIF_CTRL_RUN);

	lcdif_write(HW_LCDIF_DATA, val);

	while (lcdif_read(HW_LCDIF_CTRL) & BM_LCDIF_CTRL_RUN);

	lcdif_write(HW_LCDIF_CTRL1_CLR, BM_LCDIF_CTRL1_CUR_FRAME_DONE_IRQ);
}

static void wr_cmd (short reg)
{
	// MSB byte first
	mpulcd_setup_panel_register(CMD, (char)(reg>>8));
	mpulcd_setup_panel_register(CMD, (char)(reg & 0xFF));
}

static void wr_dat (short data)
{
	// MSB byte first
	mpulcd_setup_panel_register(DATA, (char)(data>>8));
	mpulcd_setup_panel_register(DATA, (char)(data & 0xFF));
}

static void wr_reg (short reg, short data)
{
	wr_cmd(reg);
	wr_dat(data);
}

static void mpulcd_tasklet_func(unsigned long param)
{
	/* Return to 0,0 coordination */
	wr_reg(0x20, 0);
    wr_reg(0x21, 0);
    wr_cmd(0x22);

	lcdif_write(HW_LCDIF_CTRL_SET,
		BM_LCDIF_CTRL_DATA_SELECT);

	lcdif_write(HW_LCDIF_TRANSFER_COUNT,
		BF_LCDIF_TRANSFER_COUNT_V_COUNT(240) |
		BF_LCDIF_TRANSFER_COUNT_H_COUNT(3*320));

#if 0
	/* Swap data start */
	lcdif_write(HW_LCDIF_CTRL_CLR,
		BM_LCDIF_CTRL_INPUT_DATA_SWIZZLE); // Clear the field

	// Swap bytes within each half-word
	lcdif_write(HW_LCDIF_CTRL_SET,
				BF_LCDIF_CTRL_INPUT_DATA_SWIZZLE(0x3));
	/* Swap data end */
#endif

	lcdif_write(HW_LCDIF_CTRL1_SET,
		BM_LCDIF_CTRL1_CUR_FRAME_DONE_IRQ_EN);

	lcdif_write(HW_LCDIF_CUR_BUF, inb_phys);

	mxs_lcdif_run();



}

static int mpulcd_start_refresh(void *param, struct mxs_platform_fb_entry *pentry)
{

	tasklet_schedule(&mpulcd_tasklet);

	return 0;
}

static void mpulcd_init_lcdif(void)
{
	lcdif_write(HW_LCDIF_CTRL_CLR,
		BM_LCDIF_CTRL_CLKGATE |
		BM_LCDIF_CTRL_SFTRST);

	lcdif_write(HW_LCDIF_CTRL,
		BF_LCDIF_CTRL_LCD_DATABUS_WIDTH(BV_LCDIF_CTRL_LCD_DATABUS_WIDTH__8_BIT) |
		BF_LCDIF_CTRL_WORD_LENGTH(BV_LCDIF_CTRL_WORD_LENGTH__8_BIT));

	lcdif_write(HW_LCDIF_CTRL1_CLR,
		BM_LCDIF_CTRL1_BYTE_PACKING_FORMAT);

	lcdif_write(HW_LCDIF_CTRL1_SET,
		BF_LCDIF_CTRL1_BYTE_PACKING_FORMAT(0x7)); // 0x3

	lcdif_write(HW_LCDIF_TIMING, 0x01010101);
}

static void mpulcd_init_panel_hw(void)
{

       	int i;

	    wr_reg(0x00e7,0x0010);
        wr_reg(0x0000,0x0001);
        wr_reg(0x0001,0x0100);
        wr_reg(0x0002,0x0700);
     	// wr_reg(0x0003,0x1018); // 32 bit
     	wr_reg(0x0003,0xC018); // 8bitx3 transfer
     	//wr_reg(0x0003,0x0018); // 8bitx2 transfer
        wr_reg(0x0004,0x0000);
        wr_reg(0x0008,0x0207);
        wr_reg(0x0009,0x0000);
        wr_reg(0x000a,0x0000);//display setting
        wr_reg(0x000c,0x0001);//display setting
        wr_reg(0x000d,0x0000);//0f3c
        wr_reg(0x000f,0x0000);
        wr_reg(0x0010,0x0000);
        wr_reg(0x0011,0x0007);
        wr_reg(0x0012,0x0000);
        wr_reg(0x0013,0x0000);
        mdelay(50);
        wr_reg(0x0010,0x1590);
        wr_reg(0x0011,0x0227);
        mdelay(50);
        wr_reg(0x0012,0x009c);
        mdelay(50);
        wr_reg(0x0013,0x1900);
        wr_reg(0x0029,0x0023);
        wr_reg(0x002b,0x000e);
        mdelay(50);
        wr_reg(0x0020,0x0000);
        wr_reg(0x0021,0x013f);
        mdelay(50);
        wr_reg(0x0030,0x0007);
        wr_reg(0x0031,0x0707);
        wr_reg(0x0032,0x0006);
        wr_reg(0x0035,0x0704);
        wr_reg(0x0036,0x1f04);
        wr_reg(0x0037,0x0004);
        wr_reg(0x0038,0x0000);
        wr_reg(0x0039,0x0706);
        wr_reg(0x003c,0x0701);
        wr_reg(0x003d,0x000f);
        mdelay(50);
        wr_reg(0x0050,0x0000);
        wr_reg(0x0051,0x00ef);
        wr_reg(0x0052,0x0000);
        wr_reg(0x0053,0x013f);
        wr_reg(0x0060,0xa700);
        wr_reg(0x0061,0x0001);
        wr_reg(0x006a,0x0000);
        wr_reg(0x0080,0x0000);
        wr_reg(0x0081,0x0000);
        wr_reg(0x0082,0x0000);
        wr_reg(0x0083,0x0000);
        wr_reg(0x0084,0x0000);
        wr_reg(0x0085,0x0000);
        wr_reg(0x0090,0x0010);
        wr_reg(0x0092,0x0000);
        wr_reg(0x0093,0x0003);
        wr_reg(0x0095,0x0110);
        wr_reg(0x0097,0x0000);
        wr_reg(0x0098,0x0000);
        wr_reg(0x0007,0x0133);
        wr_reg(0x0020,0x0000);
        wr_reg(0x0021,0x013f);

        mdelay(50);
#if 0
        wr_reg(0x20, 0);
        wr_reg(0x21, 0);
        wr_cmd(0x22);

	    //lcdif_write(HW_LCDIF_TIMING, 0x01010101);

	    for(i = 0; i < (320*240); i++)
	    {
		   wr_dat(0x000F);
	    }
#endif

}

static int mpulcd_init_panel(struct device *dev, dma_addr_t phys, int memsize,
		struct mxs_platform_fb_entry *pentry)
{
	int ret = 0;

	lcd_clk = clk_get(dev, "lcdif");
	if (IS_ERR(lcd_clk)) {
		ret = PTR_ERR(lcd_clk);
		goto out;
	}

	ret = clk_enable(lcd_clk);
	if (ret)
		goto out1;

	ret = clk_set_rate(lcd_clk, 24000000);
	if (ret)
		goto out2;

	mpulcd_init_lcdif();
	mxs_lcdif_dma_init(dev, phys, memsize);
	inb_phys = phys;
	mpulcd_init_panel_hw();
	tasklet_init(&mpulcd_tasklet, mpulcd_tasklet_func, (unsigned long)NULL);
	spin_lock_init(&mpulcd_lock);
	mxs_lcdif_notify_clients(MXS_LCDIF_PANEL_INIT, pentry);

	return 0;

out2:
	clk_disable(lcd_clk);
out1:
	clk_put(lcd_clk);
out:
	return ret;
}

static void mpulcd_display_on(void)
{
	tasklet_schedule(&mpulcd_tasklet);
}

static void mpulcd_display_off(void)
{
	// mpulcd_setup_panel_register(CMD, 0x28);
	// Turn off the LCD
}

static void mpulcd_release_panel(struct device *dev,
		struct mxs_platform_fb_entry *pentry)
{

	mxs_lcdif_notify_clients(MXS_LCDIF_PANEL_RELEASE, pentry);
	mpulcd_display_off();
	mxs_lcdif_dma_release();
	clk_disable(lcd_clk);
	clk_put(lcd_clk);
	tasklet_kill(&mpulcd_tasklet);
}

static int mpulcd_pan_display(dma_addr_t addr)
{

	spin_lock_bh(&mpulcd_lock);

	inb_phys = addr;

	spin_unlock_bh(&mpulcd_lock);

	return 0;
}

static struct mxs_platform_fb_entry fb_entry = {
	.name           = "ili9325",
	.x_res          = 240,
	.y_res          = 320,
	.bpp            = 32,
	.lcd_type       = MXS_LCD_PANEL_SYSTEM,
	.init_panel     = mpulcd_init_panel,
	.release_panel  = mpulcd_release_panel,
	.run_panel      = mpulcd_display_on,
	.stop_panel     = mpulcd_display_off,
	.pan_display    = mpulcd_pan_display,
	.update_panel   = mpulcd_start_refresh,
};

static int __init register_devices(void)
{
	struct platform_device *pdev;

	pdev = mxs_get_device("mxs-fb", 0);
	if (pdev == NULL || IS_ERR(pdev))
		return -ENODEV;

	mxs_lcd_register_entry(&fb_entry, pdev->dev.platform_data);

	return 0;
}

subsys_initcall(register_devices);
